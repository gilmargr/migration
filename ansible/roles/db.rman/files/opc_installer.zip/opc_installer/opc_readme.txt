Backup on the Oracle Cloud - Using the Oracle Database Cloud Backup Module

This is the README file for installing, configuring, and using the
Oracle Database Cloud Backup Module to back up an Oracle database to
Oracle Database Backup Service (ODBS) (also referred to as
 Oracle Public Cloud (OPC) in this document).

--------------------------------------------------------------------
I. What you need to have before starting the installation

Using this service requires an Oracle Database Backup
Service account, and the software library and associated
files. Before you run the installer, verify that you have:

1. Your Oracle Database Backup Service Username and Password

   You obtain these two credentials at https://cloud.oracle.com.

2. The installer: opc_install.jar

   The installer will download the library appropriate to the
   platform it is running on. It will also create the library
   configuration file and the Oracle Wallet where the credentials
   are stored.

   The installer jar file is included in the same zip file as this
   README file.

4. Java 1.7 on the computer where the installer will run.
   The installer requires Java 1.7 to run. 

5. Database Version Support: The Oracle Database Cloud Backup Module
   can be used to backup the following supported versions of Oracle
   Database: Oracle Database 10g Release 2 or higher.


--------------------------------------------------------------------
II. Installing the Library

Execute the installer supplying all the mandatory parameters in one
line, each hyphen-preceded label followed by its value.

First run the installer without any parameters:

 % java -jar opc_install.jar 

to get a usage message, whose parameters are explained below. From
the preceding section, you should have the values for all the
mandatory parameters.  Check the optional parameters; for example,
you may need to know the proxy name and credentials in your
installation.  Ensure you have Java 1.7 and $ORACLE_HOME is
correctly defined.  Note: in this readme we use "/orclhome" as the
value of $ORACLE_HOME to reduce clutter. In your installation your
value may be something like /u01/oracle/product/11.2.0, for example.

    -host:          Host name for the Oracle Public Cloud account.
                 
It is recommended to use this parameter to specify the host to which
backups to be sent.

   -serviceName:    The service name for the OPC account
   -identityDomain: The identity domain for the OPC account

Service name and identity domain are deprecated options. They are in
effect only when -host option is not specified. When in effect,
connection to OPC is set up using the host
https://[IdentityDomain].storage.oraclecloud.com/v1/
[ServiceName]-[IdentityDomain].

   -opcId:          The userid for the Oracle Public Cloud account
   -opcPass:        The password for the Oracle Public Cloud account

The OPC credentials are mandatory.

   -walletDir:      Directory to store wallet

The location for the Oracle Wallet used to store OPC credentials is
mandatory.

Suggested Unix location:    $ORACLE_HOME/dbs/opc_wallet
Suggested Windows location: $ORACLE_HOME\database\opc_wallet

   -configFile:   File name of config file

The location where the configuration file will reside. If omitted, the
installer will create the configuration file and place it in a
default system-dependent location. Optional. 

Default Unix location:    $ORACLE_HOME/dbs/opc<ORACLE_SID>.ora
Default Windows location: $ORACLE_HOME\database\opc<ORACLE_SID>.ora

   -libDir:      Directory to store library

The location where the library will be placed. If this parameter is
omitted, the installer does not download the library. Optional.
Usually you would want to download the library. The only reason
to omit downloading the library is if you are using the install
tool to regenerate the wallet and configuration file in an Oracle
Home where the Oracle Database Cloud Backup Module has previously
been installed.

Suggested Unix location:    $ORACLE_HOME/lib
Suggested Windows location: $ORACLE_HOME\bin

    -libPlatform:   The desired platform for the library

The install tool will usually be able to determine the correct
platform automatically by examining the system where it is
running.

The only reason to use this parameter is if the install tool
complains that it can't identify your system (in which case
you should also let Oracle know so we can fix the install tool),
or if you need to download the library for use on a different
system.

In this version the supported values for the parameter are:
linux64, windows64, solaris_sparc64, solaris_x64, zlinux64,
hpux_ia64, aix_ppc64

   -proxyHost:   HTTP proxy server
   -proxyPort:   HTTP proxy server port
   -proxyID:	  HTTP proxy server username
   -proxyPass:	  HTTP proxy server password

The name and port of the HTTP proxy server, if required. If the proxy
server is specified, the username and password, if required. Optional.

    -container:     OPC container to store backups

The name of the container to store backups. The installer will create the
specified container if it does not exist. If not specified, then the SBT
library will automatically create or find a container to store backups.

   -containerClass: OPC container storage class

The storage class of the  OPC container created by the installer or the SBT
library. The only valid values are "Standard" and "Tiering". If not specified,
the default value is either "Standard" or the storage class of the specified
container if it exists.

   -containerLTP:   File name of OPC container lifecycle tiering policy (LTP)

The file must be a JSON document specifying the time after which objects in
the OPC container will be moved to the Archive tier and type of objects that
can be excluded from being archived.

   -argFile: Reads the remainder of the command-line arguments from
             the specified file. Specify filename as "-" to read arguments from
             standard input.

   -import-all-trustcerts:
             Import all X509 certificates from Java truststore.

Now you are ready to execute the installer. Compose an invocation
populating the parameters you obtained earlier.  Either all of the
parameters must be on the same invocation line, or use the -argFile
option to read the parameters from a file.  When the installer
completes, verify that you have three items on your system: the
library, the config file, and the wallet. See Sample Installation
Run, below.


--------------------------------------------------------------------
III. Using the library: your first backup to OPC

Using RMAN, connect to your target database, and configure an RMAN
channel, specifying the library and the configuration file.

For example:

configure channel device type sbt
   parms='SBT_LIBRARY=libopc.so,
   SBT_PARMS=(OPC_PFILE=/orclhome/dbs/opct1.ora)';

Now you can issue all of your usual RMAN backup/restore commands.

You can run a quick test by doing a controlfile backup:

backup device type sbt current controlfile;

--------------------------------------------------------------------
IV. The Installer and the Library need your ODBS Credentials

The installer requires ODBS credentials to create the
wallet and other installation operations. Only your ODBS credentials
are retained when the installer has finished, and they are stored only
in the Oracle Wallet. The ODBS credentials are only used to
authenticate the library's interactions with Oracle Cloud Storage;
they are never sent anywhere else.

--------------------------------------------------------------------
V. Sample Installation Run

The following shows a sample run of the installer under Linux. 

First we ensure we have Java 1.7 and that ORACLE_HOME is defined:

% java -version
java version "1.7.0"
Java(TM) SE Runtime Environment (build 1.7.0-b147)
Java HotSpot(TM) 64-Bit Server VM (build 21.0-b17, mixed mode)
% echo $ORACLE_HOME
/orclhome

Then we invoke the installer with the parameters;

% java -jar opc_install.jar -host https://abc.storage.oraclecloud.com/v1/hr-abc
  -opcid joe@abc.com -opcPass 'Oracle$1' -libDir $ORACLE_HOME/lib
  -walletDir $ORACLE_HOME/dbs/opc_wallet
  -proxyHost www-proxy.smallcompany.com -proxyPort 80
Oracle Database Cloud Backup Module Install Tool, build 2014-03-13
Oracle Database Cloud Backup Module credentials are valid.
Oracle Database Cloud Backup Module wallet created in directory /orclhome/dbs/opc_wallet.
Oracle Database Cloud Backup Module initialization file /orclhome/dbs/opct1.ora created.
Downloading Oracle Database Cloud Backup Module Software Library from file
opc_linux64.zip.
Downloaded 13165919 bytes in 204 seconds. Transfer rate was 64538 bytes/second.
Download complete.
Extracted file /orclhome/lib/libopc.so

--------------------------------------------------------------------
VI. Encrypting Backup

Oracle Database Cloud Backup Module enforces RMAN encryption and will not let
the backups to happen if the backup is not encrypted. For eg, if the backup is
not encrypted, an error message similar to the one shown below is returned.

RMAN-00571: ===========================================================
RMAN-00569: =============== ERROR MESSAGE STACK FOLLOWS ===============
RMAN-00571: ===========================================================
RMAN-03009: failure of backup command on ORA_SBT_TAPE_1 channel at 02/14/2014 14:00:43
ORA-27030: skgfwrt: sbtwrite2 returned error
ORA-19511: non RMAN, but media manager or vendor specific failure, error text:
   KBHS-01602: backup piece 14p0jso8_1_1 is not encrypted

User has to configure encrypted backups in order to do send backups to ODBS.
RMAN supports two methods of Backup Encryption. 1) Transparent Data Encryption
(TDE) 2) Password Encryption.  Please refer manual on how to setup Backup
Encryption. 

For eg, password encryption can be done using
  RMAN> set encryption on identified by "myPassw0rd" only;
  RMAN> backup device type sbt database;

During restore, you need to remember the password and supply it by following
command.
  set decryption identified by "myPassw0rd";

--------------------------------------------------------------------
VII. Encrypting Backup Via Enterprise Manager

Due to a bug, you may encounter the following error message while trying to run an encrypted backup 
through Enterprise Manager:

"Encryption is only supported when backing up to disk, or when backing up to tape
 using Oracle SBT library like (Oracle Database Cloud Backup Module).
 Please specify a different backup destination"

On Linux, You can get around this problem by creating the following symbolic links: 

% ln -s <libDir/libopc.so> $ORACLE_HOME/lib/libobk.so  
% ln -s <configFile> $ORACLE_HOME/dbs/opc<ORACLE_SID>.ora  

Where

libDir : Directory to store library
configFile : File name of config file 
